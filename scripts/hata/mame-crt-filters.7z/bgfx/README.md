# **BGFX shaders** #

Contains definitions for BGFX shaders, shader chains and effects.

Licensed under [The BSD 3-Clause License](http://opensource.org/licenses/BSD-3-Clause) by Ryan Holtz and MAME Development Team
